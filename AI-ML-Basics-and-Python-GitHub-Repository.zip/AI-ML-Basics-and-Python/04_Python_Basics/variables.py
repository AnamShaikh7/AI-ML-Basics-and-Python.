# Variables store values.
name = "Anam"
age = 21
cgpa = 8.30

print("Name:", name)
print("Age:", age)
print("CGPA:", cgpa)
