# A list stores multiple items in one variable.
fruits = ["apple", "banana", "mango"]

print("All fruits:", fruits)
print("First fruit:", fruits[0])

fruits.append("orange")
print("After adding an item:", fruits)

for fruit in fruits:
    print(fruit)
