# A function is a reusable block of code.
def greet(name):
    return f"Hello, {name}!"

message = greet("Anam")
print(message)

def add_numbers(a, b):
    return a + b

print("Sum:", add_numbers(5, 7))
