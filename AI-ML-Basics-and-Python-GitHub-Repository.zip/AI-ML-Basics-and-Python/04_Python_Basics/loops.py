# A for loop repeats a block for each item in a sequence.
for number in range(1, 6):
    print(number)

# A while loop repeats while its condition is True.
count = 1
while count <= 3:
    print("Count:", count)
    count += 1
