# Study Notes: AI, ML, Deep Learning and Python

## 1. Artificial Intelligence
AI is the field of creating computer systems that can perform tasks associated with human intelligence, such as recognising speech, understanding text, solving problems, and making recommendations.

## 2. Machine Learning
ML is a subset of AI. It allows computers to learn patterns from examples and data so they can make predictions or decisions on new information.

### Common types of ML
- **Supervised learning:** Learns from labelled examples. Example: predicting house prices from past sales.
- **Unsupervised learning:** Finds patterns in data without labelled answers. Example: grouping customers by purchasing behaviour.
- **Reinforcement learning:** Learns through actions, feedback, and rewards. Example: an agent learning to navigate a simulated environment.

## 3. Deep Learning
Deep Learning is a subset of ML that uses neural networks with multiple layers. It is used in tasks such as image recognition, speech recognition, and language processing.

## 4. AI, ML and Deep Learning
AI is the broadest concept; ML is one way to build AI; Deep Learning is one approach within ML.

## 5. Real-world applications
- Healthcare: medical-image support and workflow assistance.
- Education: personalised learning and feedback.
- Finance: fraud detection.
- Transport: route optimisation and driver assistance.
- Retail: recommendations and demand forecasting.
- Agriculture: crop monitoring.
- Accessibility: speech recognition and translation.

## 6. Python basics
Python is a general-purpose programming language known for readable syntax. It is widely used in automation, data analysis, web development, and AI/ML.

### Variables and data types
A variable is a name that refers to a value.
```python
student = "Anam"   # string
age = 21           # integer
score = 8.3        # float
is_learning = True # boolean
```

### Conditions
Conditions allow a program to make decisions.
```python
number = 8
if number % 2 == 0:
    print("Even")
else:
    print("Odd")
```

### Loops
A `for` loop iterates over a sequence. A `while` loop repeats while a condition remains true.
```python
for i in range(1, 4):
    print(i)
```

### Functions
Functions organise reusable code.
```python
def multiply(a, b):
    return a * b

print(multiply(3, 4))
```

### Lists
Lists store ordered collections of items.
```python
subjects = ["AI", "ML", "Python"]
subjects.append("SQL")
print(subjects)
```

## 7. Practice tasks
1. Print your name and a short introduction.
2. Add two numbers entered by the user.
3. Check whether a number is even or odd.
4. Find the largest of three numbers.
5. Print a multiplication table.
6. Write a function that returns the square of a number.
7. Create a list of five favourite subjects and print each item.

## 8. Good programming habits
- Use meaningful variable names.
- Indent Python code consistently.
- Add comments where they clarify the logic.
- Test programs with different inputs.
- Read error messages carefully and correct the cause.
