def square(number):
    return number * number

value = float(input("Enter a number: "))
print("Square:", square(value))
