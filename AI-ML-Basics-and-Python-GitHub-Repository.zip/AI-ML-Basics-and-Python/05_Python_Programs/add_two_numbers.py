first = float(input("Enter the first number: "))
second = float(input("Enter the second number: "))

total = first + second
print("Sum:", total)
