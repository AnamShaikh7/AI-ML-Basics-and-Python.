first = float(input("Enter first number: "))
operator = input("Choose an operation (+, -, *, /): ")
second = float(input("Enter second number: "))

if operator == "+":
    result = first + second
elif operator == "-":
    result = first - second
elif operator == "*":
    result = first * second
elif operator == "/":
    if second == 0:
        result = None
        print("Error: cannot divide by zero.")
    else:
        result = first / second
else:
    result = None
    print("Invalid operator.")

if result is not None:
    print("Result:", result)
