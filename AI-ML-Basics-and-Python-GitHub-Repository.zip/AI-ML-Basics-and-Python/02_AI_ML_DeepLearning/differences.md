# AI vs Machine Learning vs Deep Learning

## Artificial Intelligence (AI)
The broad field of creating computer systems that perform tasks associated with human intelligence.

## Machine Learning (ML)
A subset of AI that enables systems to learn patterns from data and improve their predictions or decisions through experience.

## Deep Learning (DL)
A subset of ML that uses multi-layered artificial neural networks. It is especially useful for complex data such as images, audio, and text, and often requires substantial data and computing power.

## Relationship
Deep Learning is part of Machine Learning, and Machine Learning is part of Artificial Intelligence.

```text
Artificial Intelligence
└── Machine Learning
    └── Deep Learning
```

## Comparison

| Area | Main idea | Example |
|---|---|---|
| AI | Systems performing intelligent tasks | A rule-based chess program |
| ML | Learning patterns from data | Email spam classification |
| Deep Learning | Learning with multi-layer neural networks | Image recognition |

## Remember
Not every AI system uses ML, and not every ML system uses Deep Learning.
