# AI, Machine Learning & Python Fundamentals

A beginner-friendly learning repository covering the foundations of Artificial Intelligence (AI), Machine Learning (ML), Deep Learning, real-world AI applications, and introductory Python programming.

## Learning objectives
1. Learn the basics of Artificial Intelligence and Machine Learning.
2. Understand the difference between AI, ML, and Deep Learning.
3. Explore real-world AI applications.
4. Install Python and practise variables, loops, functions, and lists.
5. Write beginner-friendly Python programs.

## Repository structure
- `01_Introduction_to_AI_ML/` — introductory concepts
- `02_AI_ML_DeepLearning/` — comparison of AI, ML, and Deep Learning
- `03_Real_World_AI_Applications/` — practical applications across industries
- `04_Python_Basics/` — short examples of core Python concepts
- `05_Python_Programs/` — beginner programming exercises
- `notes/` — consolidated study notes in Markdown and PDF

## Requirements
- Python 3.10 or later (Python 3.x is sufficient for the examples)
- A code editor such as Visual Studio Code, or Python IDLE

## Run a program
Open a terminal in the repository and run, for example:

```bash
python 05_Python_Programs/calculator.py
```

## Note
This is an introductory learning project. The examples are intentionally simple and are designed for practice and understanding.
