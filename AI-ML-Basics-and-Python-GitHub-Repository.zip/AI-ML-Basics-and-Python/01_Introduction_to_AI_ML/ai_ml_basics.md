# Introduction to Artificial Intelligence and Machine Learning

## What is Artificial Intelligence?
Artificial Intelligence (AI) is a field of computer science focused on building systems that can perform tasks that normally require human-like intelligence. Examples include understanding language, recognising images, solving problems, and making recommendations.

## What is Machine Learning?
Machine Learning (ML) is a branch of AI in which computers learn patterns from data and use those patterns to make predictions or decisions, rather than relying only on explicitly written rules.

## Important terms
- **Data:** Information used by a computer system.
- **Algorithm:** A set of steps used to solve a problem.
- **Model:** A system trained on data to identify patterns or make predictions.
- **Training:** The process of helping a model learn from examples.
- **Prediction:** The output produced by a trained model for new input.

## Simple example
An email spam filter can learn from examples of spam and non-spam messages. After training, it can estimate whether a new email is likely to be spam.

## Key takeaway
AI is the broader field. ML is one approach used to create AI systems.
